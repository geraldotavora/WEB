package com.ufc.br.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ufc.br.model.Produto;
import com.ufc.br.repository.ProdutoRepository;
import com.ufc.br.util.FileUtil;

@Service
public class ProdutoService {

	@Autowired
	private ProdutoRepository prodRepository;
	
	public void addProd(Produto produto, MultipartFile imagem) {
		String caminho = "images/"+ produto.getNome()+".png";
		FileUtil.salvarImagem(caminho, imagem);
		
		prodRepository.save(produto);
	}
	
	public void remove(long id) {
		prodRepository.deleteById(id);
	}
	
	public void buscarPorId(long id) {
		prodRepository.getOne(id);
	}
	
	public List<Produto> listarProdutos(){
		return prodRepository.findAll();
	}
}
