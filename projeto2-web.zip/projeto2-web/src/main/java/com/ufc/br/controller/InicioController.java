package com.ufc.br.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ufc.br.model.Produto;
import com.ufc.br.service.ProdutoService;

@Controller
public class InicioController {

	@Autowired
	private ProdutoService prodRep;
	
//	@RequestMapping("/index")
//	public String paginaInicial() {
//		return "index";
//	}
	
	@RequestMapping("/index")
	public ModelAndView index() {
		List<Produto> prod = prodRep.listarProdutos();
		ModelAndView mv = new ModelAndView("index");
		mv.addObject("produtos", prod);
		return mv;
	}
	
//	@RequestMapping("/sobre")
//	public String sobre() {
//		return "sobre";
//	}
//	
//	@RequestMapping("/contato")
//	public String contato() {
//		return "contato";
//	}
//	
//	@RequestMapping("/cadastro")
//	public String cadastro() {
//		return "cadastro";
//	}
	
	
	
}
