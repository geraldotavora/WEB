package com.ufc.br.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ufc.br.model.Pessoa;
import com.ufc.br.repository.PessoaRepository;

@Service
public class PessoaService {

	@Autowired
	private PessoaRepository pessoarepository;
	
	public void addPessoa(Pessoa pessoa) {
		pessoa.setSenha(new BCryptPasswordEncoder().encode(pessoa.getSenha()));
		pessoarepository.save(pessoa);
	}
	
	public void remove(long id) {
		pessoarepository.deleteById(id);
	}
	
	public void buscarPorId(long id) {
		pessoarepository.getOne(id);
	}
	
	public List<Pessoa> listarPessoas(){
		return pessoarepository.findAll();
	}
}
