package com.ufc.br;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto2WebApplication {

	public static void main(String[] args) {
		SpringApplication.run(Projeto2WebApplication.class, args);
	}
}
