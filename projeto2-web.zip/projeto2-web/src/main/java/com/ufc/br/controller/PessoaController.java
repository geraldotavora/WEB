package com.ufc.br.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ufc.br.model.Pessoa;
import com.ufc.br.service.PessoaService;

@Controller
public class PessoaController {
	
	@Autowired
	private PessoaService pessoaService;
	
	@RequestMapping("/cadastro")
	public ModelAndView cadastroPessoa() {
		ModelAndView mv = new ModelAndView("cadastro");
		mv.addObject("pessoa", new Pessoa());
		return mv;
	}
	
	@RequestMapping("/sobre")
	public ModelAndView sobre() {
		ModelAndView mv = new ModelAndView("sobre");
		return mv;
	}
	
	@RequestMapping("/contato")
	public ModelAndView contato() {
		ModelAndView mv = new ModelAndView("contato");
		return mv;
	}
	
	@PostMapping("/salvar")
	public ModelAndView salvarPessoa(Pessoa pessoa) {
		pessoaService.addPessoa(pessoa);
		
		ModelAndView mv = new ModelAndView("redirect:/index");
		
		return mv;
	}
	
	@RequestMapping("/logar")
	public ModelAndView logar() {
		ModelAndView mv = new ModelAndView("login");
		return mv;
	}
}
