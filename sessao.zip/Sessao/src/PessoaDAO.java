import java.util.ArrayList;

public class PessoaDAO {
	ArrayList<Pessoa> pessoas = new ArrayList<>();
	
	public void CadastraPessoa() {
		pessoas.add(new Pessoa("geraldo", "15091985"));
	}
	
	Pessoa buscarPessoa(String login, String senha) {
		for(Pessoa p : pessoas) {
			if(p.getNome().equals(login) && p.getSenha().equals(senha)) {
				return p;
			}
		}
		return null;
	}
}
