

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class efetuarlogin
 */
@WebServlet("/efetuarlogin")
public class efetuarlogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public efetuarlogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession sessao = request.getSession();
		
		String login = request.getParameter("login");
		String senha = request.getParameter("senha");
		
		PessoaDAO pessoaDAO = new PessoaDAO();
		pessoaDAO.CadastraPessoa();
		
		Pessoa pbusca = pessoaDAO.buscarPessoa(login, senha);
		
		if(pbusca != null) {
			sessao.setAttribute("usuarioLogado", login);
			response.sendRedirect("TelaInicial");
		}else {
			response.sendRedirect("loginForm");
		}
		
	}

	
}
